/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","es-mx",{title:"Propiedades del marcador de posición",toolbar:"Marcador de posición",name:"Nombre del marcador de posición",invalidName:"El marcador de posición no puede estar vacío y no puede contener alguno de los siguientes caracteres: [, ], \x3c, \x3e",pathName:"marcador de posición"});