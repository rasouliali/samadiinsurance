export default {
  'to top': 0,
  'to right': 90,
  'to bottom': 180,
  'to left': 270,
  'to right top': 45,
  'to top right': 45,
  'to bottom right': 135,
  'to right bottom': 135,
  'to left bottom': 225,
  'to bottom left': 225,
  'to top left': 315,
  'to left top': 315
};
